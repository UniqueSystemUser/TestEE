package com.uniquesystem.hrms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name="HRMS_USER_LOGIN_INFO")
public class UserLogin {

	@javax.persistence.Id
	@Column(name="LOGIN_ID",nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Id;
	
	@Column(name="EMP_ID", nullable=false)
	private String EmpId;
	
	@Column(name="name")
	private String strFstname;
	
	@Column(name="email")
	private String stremail;
	
	@Column(name="password")
	private String strpassword;
	
	@Column(name="IS_LOGIN")
	private boolean boois_login;

	public UserLogin(UserLogin users) {
		this.Id = users.getId();
		this.stremail =users.getStremail();
		this.strpassword = users.getStrpassword();
		this.strFstname = users.getStrFstname();
		this.boois_login = users.isBoois_login();
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getStrFstname() {
		return strFstname;
	}

	public void setStrFstname(String strFstname) {
		this.strFstname = strFstname;
	}

	public String getStremail() {
		return stremail;
	}

	public void setStremail(String stremail) {
		this.stremail = stremail;
	}

	public String getStrpassword() {
		return strpassword;
	}

	public void setStrpassword(String strpassword) {
		this.strpassword = strpassword;
	}

	public boolean isBoois_login() {
		return boois_login;
	}

	public void setBoois_login(boolean boois_login) {
		this.boois_login = boois_login;
	}
	
	
}
