package com.uniquesystem.hrms.util;

public class Constants {

	public static final String BLANK 					= "";
	public static final String ROOT_APP_URL				= "hrms";
	public static final String FORGET_PASSWORD_MAIL_SUB = "Rest Password mail";
	public static final String SYSTEM_MAIL_ADD			= "hrmssystem@uniquesystem.co.in";
	public static final String FORGET_PASSWORD_MAIL_TEMP ="Forget-Password.html";
}
