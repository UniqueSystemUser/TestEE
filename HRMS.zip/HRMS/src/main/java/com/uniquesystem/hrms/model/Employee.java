package com.uniquesystem.hrms.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.uniquesystem.hrms.util.EmployeeIdentity;

@Entity
//@IdClass(EmployeeIdentity.class)
@Table(name="HRMS_EMPLOYEE_INFO")
@SecondaryTables({
	@SecondaryTable(name="HRMS_EMPLOYEE_ADD", pkJoinColumns= {
			@PrimaryKeyJoinColumn(name="EMP_ID", referencedColumnName="EMP_ID" )//,
			//@PrimaryKeyJoinColumn(name="EMP_FST_NAME", referencedColumnName="EMP_FST_NAME" ),
	} ),
    @SecondaryTable(name="HRMS_EMPLOYEE_BK_ACC_INFO", pkJoinColumns= {
    		@PrimaryKeyJoinColumn(name="EMP_ID", referencedColumnName="EMP_ID")//,
    		//@PrimaryKeyJoinColumn(name="EMP_FST_NAME", referencedColumnName="EMP_FST_NAME")
    })
})
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value= {"dtCreatedAt","dtModifiedAt"})
public class Employee {
	
	@Id
	@NotNull
	@Column(name="EMP_ID")
	private Long lngEmpId;

	@Size(max = 20)
	@Column(name="EMP_FST_NAME")
	private String strFstNme;
	
	@Column(name="EMP_LST_NAME")
	private String strLst_Name;
	
	@Column(name="EMP_MAIL_ADD")
	private String strOffEmail;

	@Column(name="EMP_MAIL_ADD1")
	private String strPerEmail;
	
	@Column(name="EMP_DOB")
	private Date dtDOB;
	
	@Column(name="EMP_GENDER")
	private String strGender;
	
	@Column(name="EMP_DOJ")
	private Date dtJoindate;
	
	@Column(name="EMP_MARIT_STUS")
	private String strMaritalStat;
	
	@Column(name="EMP_MOB_NO")
	private long lngMobileNum;
	
	@Column(name="EMP_BLD_GRP")
	private String strBloodGrp;
	
	@Column(name="EMP_PASP_NUM")
	private String strPassNum; 
	
	@Column(name="EMP_FTR_NME")
	private String strFtrName;
	
	@Column(name="EMP_UAN_NUM")
	private String strUanNum;
	
	@Column(name="EMP_PF_NUM")
	private String strPFNum;
	
	@Column(name="IS_DELETED")
	private char chrIsDeleted='N';
	
	
	@Column(name="EMP_CREA_DATE",nullable=false,updatable=false)
	@Temporal(TemporalType.DATE)
	@CreatedDate
	private Date dtCreatedAt;
	
	@Column(name="EMP_MODI_DATE",nullable=false)
	@Temporal(TemporalType.DATE)
	@LastModifiedDate
	private Date dtModifiedAt;
	
	//HRMS_EMPLOYEE_INFO ends here
	
	@Column(table="HRMS_EMPLOYEE_ADD", name="EMP_CUR_ADD")
	private String strCurrAdd;

	@Column(table="HRMS_EMPLOYEE_ADD", name="EMP_CUR_CTY")
	private String strCurrCty;
	
	@Column(table="HRMS_EMPLOYEE_ADD",name="EMP_CUR_CUN")
	private String strCurrCun;
	
	@Column(table="HRMS_EMPLOYEE_ADD",name="EMP_CUR_CDE")
	private String strCurrCde; 
	
	@Column( table="HRMS_EMPLOYEE_ADD",name="EMP_PER_ADD")
	private String strPerAdd;
	
	@Column( table="HRMS_EMPLOYEE_ADD",name="EMP_PER_CTY")
	private String strPerCty;
	
	@Column( table="HRMS_EMPLOYEE_ADD",name="EMP_PER_CUN")
	private String strPerCun;
	
	@Column( table="HRMS_EMPLOYEE_ADD",name="EMP_PER_CDE")
	private String strPerCde; 
	
	//HRMS_EMPLOYEE_ADD ends here...
	
	@Column(table="HRMS_EMPLOYEE_BK_ACC_INFO", name="EMP_BK_ACC_NUM")
	private long lngAccNum;
	
	@Column(table="HRMS_EMPLOYEE_BK_ACC_INFO", name="EMP_BK_ACC_NME")
	private String strBkNme;
	
	@Column(table="HRMS_EMPLOYEE_BK_ACC_INFO", name="EMP_BK_ACC_BRH")
	private String strBrhNme;
	
	@Column(table="HRMS_EMPLOYEE_BK_ACC_INFO", name="EMP_BK_IFSC_CODE")
	private String strBkIfscCode;
	//HRMS_EMPLOYEE_BK_ACC_INFO
	
	public String getStrEmail() {
		return strOffEmail;
	}

	public void setStrEmail(String strEmail) {
		this.strOffEmail = strEmail;
	}
	
	public String getStrPerEmail() {
		return strPerEmail;
	}

	public void setStrPerEmail(String strPerEmail) {
		this.strPerEmail = strPerEmail;
	}

	public long getLngMobileNum() {
		return lngMobileNum;
	}

	public void setLngMobileNum(long lngMobileNum) {
		this.lngMobileNum = lngMobileNum;
	}

	public Date getDtCreatedAt() {
		return dtCreatedAt;
	}

	public Long getLngEmpId() {
		return lngEmpId;
	}

	public void setLngEmpId(Long lngEmpId) {
		this.lngEmpId = lngEmpId;
	}

	public String getStrFstNme() {
		return strFstNme;
	}

	public void setStrFstNme(String strFst_Nme) {
		this.strFstNme = strFst_Nme;
	}

	public void setDtCreatedAt(Date dtCreatedAt) {
		this.dtCreatedAt = dtCreatedAt;
	}

	public Date getDtModifiedAt() {
		return dtModifiedAt;
	}

	public String getStrGender() {
		return strGender;
	}

	public void setStrGender(String strGender) {
		this.strGender = strGender;
	}

	public Date getDtJoindate() {
		return dtJoindate;
	}

	public void setDtJoindate(Date dtJoindate) {
		this.dtJoindate = dtJoindate;
	}

	public String getStrMaritalStat() {
		return strMaritalStat;
	}

	public void setStrMaritalStat(String strMaritalStat) {
		this.strMaritalStat = strMaritalStat;
	}

	public String getStrBloodGrp() {
		return strBloodGrp;
	}

	public void setStrBloodGrp(String strBloodGrp) {
		this.strBloodGrp = strBloodGrp;
	}

	public String getStrPassNum() {
		return strPassNum;
	}

	public void setStrPassNum(String strPassNum) {
		this.strPassNum = strPassNum;
	}

	public String getStrFtrName() {
		return strFtrName;
	}

	public void setStrFtrName(String strFtrName) {
		this.strFtrName = strFtrName;
	}

	public String getStrUanNum() {
		return strUanNum;
	}

	public void setStrUanNum(String strUanNum) {
		this.strUanNum = strUanNum;
	}

	public String getStrPFNum() {
		return strPFNum;
	}

	public void setStrPFNum(String strPFNum) {
		this.strPFNum = strPFNum;
	}

	public String getStrCurrAdd() {
		return strCurrAdd;
	}

	public void setStrCurrAdd(String strCurrAdd) {
		this.strCurrAdd = strCurrAdd;
	}

	public String getStrCurrCty() {
		return strCurrCty;
	}

	public void setStrCurrCty(String strCurrCty) {
		this.strCurrCty = strCurrCty;
	}

	public String getStrCurrCun() {
		return strCurrCun;
	}

	public void setStrCurrCun(String strCurrCun) {
		this.strCurrCun = strCurrCun;
	}

	public String getStrCurrCde() {
		return strCurrCde;
	}

	public void setStrCurrCde(String strCurrCde) {
		this.strCurrCde = strCurrCde;
	}

	public String getStrPerAdd() {
		return strPerAdd;
	}

	public void setStrPerAdd(String strPerAdd) {
		this.strPerAdd = strPerAdd;
	}

	public String getStrPerCty() {
		return strPerCty;
	}

	public void setStrPerCty(String strPerCty) {
		this.strPerCty = strPerCty;
	}

	public String getStrPerCun() {
		return strPerCun;
	}

	public void setStrPerCun(String strPerCun) {
		this.strPerCun = strPerCun;
	}

	public String getStrPerCde() {
		return strPerCde;
	}

	public void setStrPerCde(String strPerCde) {
		this.strPerCde = strPerCde;
	}

	public void setDtModifiedAt(Date dtModifiedAt) {
		this.dtModifiedAt = dtModifiedAt;
	}

	public String getStrLst_Name() {
		return strLst_Name;
	}

	public void setStrLst_Name(String strLst_Name) {
		this.strLst_Name = strLst_Name;
	}

	public Date getDtDOB() {
		return dtDOB;
	}

	public void setDtDOB(Date dtDOB) {
		this.dtDOB = dtDOB;
	}
	public char getChrIsDeleted() {
		return chrIsDeleted;
	}

	public void setChrIsDeleted(char chrIsDeleted) {
		this.chrIsDeleted = chrIsDeleted;
	}

	public long getLngAccNum() {
		return lngAccNum;
	}

	public void setLngAccNum(long lngAccNum) {
		this.lngAccNum = lngAccNum;
	}

	public String getStrBkNme() {
		return strBkNme;
	}

	public void setStrBkNme(String strBkNme) {
		this.strBkNme = strBkNme;
	}

	public String getStrBrhNme() {
		return strBrhNme;
	}

	public void setStrBrhNme(String strBrhNme) {
		this.strBrhNme = strBrhNme;
	}

	public String getStrBkIfscCode() {
		return strBkIfscCode;
	}

	public void setStrBkIfscCode(String strBkIfscCode) {
		this.strBkIfscCode = strBkIfscCode;
	}

/*	public String getStrFatName() {
		return strFatName;
	}

	public void setStrFatName(String strFatName) {
		this.strFatName = strFatName;
	}
	*/
	
}
