package com.uniquesystem.hrms.service;

import java.util.Optional;

import com.uniquesystem.hrms.model.UserLogin;

public interface UserService {
	public Optional<UserLogin> finduserBystrEmail(String email);
	
	public Optional<UserLogin> finduserBystrRestToken(String token);

	void save(UserLogin user);
	
}
