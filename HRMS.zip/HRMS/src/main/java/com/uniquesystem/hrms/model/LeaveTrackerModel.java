package com.uniquesystem.hrms.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HRMS_LEAVE_TRACKER")
public class LeaveTrackerModel {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LEAVE_APPL_ID")
	private Long lngLeaveId;
	
	@Column(name="LEAVE_REQ_DT")
	private Date reqDate;
	
	@Column(name="LEAVE_START_DT")
	private Date startDate;
	
	@Column(name="LEAVE_END_DT")
	private Date endDate;
	
	@Column(name="NO_OF_DAYS")
	private int inDays;
	
	@Column(name="LEAVE_REASON")
	private String strReason;
	
	@Column(name="LEAVE_STATUS")
	private String strAppStatus;
	
	@Column(name="LEAVE_APPR_BY")
	private String strApprovedBy;
	
	@Column(name="LEAVE_REMKS")
	private String strRemarks;

	public Long getLngLeaveId() {
		return lngLeaveId;
	}

	public void setLngLeaveId(Long lngLeaveId) {
		this.lngLeaveId = lngLeaveId;
	}

	public Date getReqDate() {
		return reqDate;
	}

	public void setReqDate(Date reqDate) {
		this.reqDate = reqDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getInDays() {
		return inDays;
	}

	public void setInDays(int inDays) {
		this.inDays = inDays;
	}

	public String getStrReason() {
		return strReason;
	}

	public void setStrReason(String strReason) {
		this.strReason = strReason;
	}

	public String getStrAppStatus() {
		return strAppStatus;
	}

	public void setStrAppStatus(String strAppStatus) {
		this.strAppStatus = strAppStatus;
	}

	public String getStrApprovedBy() {
		return strApprovedBy;
	}

	public void setStrApprovedBy(String strApprovedBy) {
		this.strApprovedBy = strApprovedBy;
	}

	public String getStrRemarks() {
		return strRemarks;
	}

	public void setStrRemarks(String strRemarks) {
		this.strRemarks = strRemarks;
	}
}
