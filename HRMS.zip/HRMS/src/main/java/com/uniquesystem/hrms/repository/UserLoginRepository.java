package com.uniquesystem.hrms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uniquesystem.hrms.model.UserLogin;

@Repository("userRepository")
public interface UserLoginRepository extends JpaRepository <UserLogin, Long>{

	Optional<UserLogin> findBystremail(String username);
}
