package com.uniquesystem.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.uniquesystem.hrms.model.LeaveTrackerModel;

public interface LeaveTrackerRepository extends JpaRepository<LeaveTrackerModel,Long>{

	@Modifying
	@Query("UPDATE LeaveTrackerModel l SET l.strAppStatus = :strAppStatus,l.strApprovedBy = :strApprovedBy WHERE l.lngLeaveId = :lngLeaveId")
	int updatestrAppStatus(@Param("lngLeaveId") Long lngLeaveId, @Param("strAppStatus") String strAppStatus,@Param("strApprovedBy") String strApprovedBy);
	
}
