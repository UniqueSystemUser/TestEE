package com.uniquesystem.hrms.util;

import java.io.Serializable;

public class EmployeeIdentity implements Serializable{

	private String strEmpId;

	private String strFstNme;

	public EmployeeIdentity() {
		
	}
	
	public EmployeeIdentity(String strEmp_Id,String strFst_Nme) {
		this.strEmpId = strEmp_Id;
		this.strFstNme = strFst_Nme;
	}
	@Override
	public boolean equals(Object o) {
	     if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;

	        EmployeeIdentity that = (EmployeeIdentity) o;

	        if (!strEmpId.equals(that.strEmpId)) return false;
	        return strFstNme.equals(that.strFstNme);
	    }

	    @Override
	    public int hashCode() {
	        int result = strEmpId.hashCode();
	        result = 31 * result + strFstNme.hashCode();
	        return result;
	    }
	public String getStrEmpId() {
		return strEmpId;
	}

	public void setStrEmpId(String strEmp_Id) {
		this.strEmpId = strEmp_Id;
	}

	public String getStrFstNme() {
		return strFstNme;
	}

	public void setStrFstNme(String strFst_Nme) {
		this.strFstNme = strFst_Nme;
	}
}
