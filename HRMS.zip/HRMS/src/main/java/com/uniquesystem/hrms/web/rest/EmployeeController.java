package com.uniquesystem.hrms.web.rest;

import java.util.List;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uniquesystem.hrms.model.Employee;
import com.uniquesystem.hrms.repository.EmployeeRepository;
import com.uniquesystem.hrms.util.ResourceNotFoundException;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/hrms")
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@PostMapping(value="/employee/add")
	public boolean addEmployeeSubmit(@Valid @RequestBody Employee employee) {
		if(employeeRepository.existsById(employee.getLngEmpId())) {
		    return false;
		}else {
		    employeeRepository.save(employee);
		    return true;
		}
	}
	
	@GetMapping(value="/employee/list")
	public List <Employee> getAllEmployee(){
		return employeeRepository.findAll();
	}
	@GetMapping(value="employee/get/{id}")
	public Employee getEmployeeById(@PathVariable(value="id") Long lngEmpId) {
		return employeeRepository.findById(lngEmpId)
				.orElseThrow(()-> new ResourceNotFoundException("Employee","id", lngEmpId));
	}
	
	@PostMapping(value="/employee/update")
	public boolean editEmployee(@Valid @RequestBody Employee employee) {
		employeeRepository.save(employee);
		return true;
	}
	
	@Transactional
	@PostMapping(value="/employee/delete")
	public boolean deleteEmployee(@Valid @RequestBody Employee employee) {
		int Results = employeeRepository.updatechrIsDeleted(employee.getLngEmpId(),employee.getStrFstNme(),employee.getChrIsDeleted());
		if(Results < 1)
			return false;
			else
			return true;
	}
}
