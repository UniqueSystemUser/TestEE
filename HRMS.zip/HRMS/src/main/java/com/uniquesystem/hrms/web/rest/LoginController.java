package com.uniquesystem.hrms.web.rest;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/hrms")
public class LoginController {

	@RequestMapping("/login")
	public boolean ApplicationLogin() {
		return true;
	}
}
